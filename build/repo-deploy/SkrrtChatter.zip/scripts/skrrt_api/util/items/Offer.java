package scripts.skrrt_api.util.items;

import org.tribot.api.General;
import org.tribot.api.Timing;
import scripts.skrrt_api.util.functions.GrandExchange07;
import scripts.skrrt_api.util.functions.Inventory07;
import scripts.skrrt_api.util.numbers.Reactions;

import java.util.ArrayList;

public class Offer {
    private String name;
    private int price;
    private int quantity;
    private boolean sell;

    public Offer(String name, int price, int quantity, boolean sell) {
        this.name = name;
        this.price = price;
        this.quantity = quantity;
        this.sell = sell;
    }

    public static boolean makeOffer(ArrayList<Offer> offers){
        ArrayList<Offer> completedOffers = new ArrayList<>();
        if(GrandExchange07.open()){
            General.sleep(Reactions.getNormal());
            for(Offer o : offers){
                General.sleep(Reactions.getNormal());
                if(Inventory07.getCount(o.name) < o.quantity){
                    int count = Inventory07.getCount(o.name);
                    GrandExchange07.offer(o.name,o.price,o.quantity - Inventory07.getCount(o.name),o.sell);
                    Timing.waitCondition(GrandExchange07::collectAll, Reactions.getAFK());
                    Timing.waitCondition(()->Inventory07.getCount(o.name) != count, Reactions.getNormal());
                } else {
                    completedOffers.add(o);
                }
            } offers.removeAll(completedOffers);
        } return offers.isEmpty();
    }

}
