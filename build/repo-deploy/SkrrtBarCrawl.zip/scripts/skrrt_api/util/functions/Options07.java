package scripts.skrrt_api.util.functions;

import org.tribot.api.General;
import org.tribot.api.Timing;
import org.tribot.api2007.Game;
import org.tribot.api2007.GameTab;
import org.tribot.api2007.Interfaces;
import org.tribot.api2007.Options;
import org.tribot.api2007.types.RSInterface;
import scripts.entityselector.Entities;
import scripts.entityselector.finders.prefabs.InterfaceEntity;
import scripts.skrrt_api.util.numbers.Reactions;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

public class Options07 extends Options {

    public static final int ALL_MASTER = 162;

    public Options07(ArrayList<Boolean> options) {
        ArrayList<Boolean> ops = new ArrayList<>();
        Collections.shuffle(options);
        while (!options.isEmpty()) {
            for (boolean option : options) {
                General.sleep(Reactions.getNormal());
                if (!option) {
                    ops.add(option);
                    General.sleep(20, 40);
                } else {
                    openOptions();
                }
            } General.println(ops);
            options.clear();
        }
        Interfaces.closeAll();
    }

    public static boolean minimiseAll(){
        RSInterface allBtn = Interfaces.get(ALL_MASTER,i -> i.getText().equals("All")).getSibling(-1);
        if(allBtn!=null && allBtn.getTextureID() !=3051){
            return allBtn.click();
        } return false;
    }


    public static boolean openOptions() {
        final int OPTIONS_MASTER = 134;
        if (Interfaces.isInterfaceSubstantiated(OPTIONS_MASTER)) {
            return true;
        }
        if (GameTab.getOpen() != GameTab.TABS.OPTIONS) {
            GameTab.open(GameTab.TABS.OPTIONS);
            Timing.waitCondition(() -> GameTab.TABS.OPTIONS.isOpen(), Reactions.getNormal());
        }
        RSInterface allSettings = Interfaces.findWhereAction("All settings");
        if (allSettings != null) {
            allSettings.click();
            return Timing.waitCondition(() -> Interfaces.isInterfaceSubstantiated(OPTIONS_MASTER), Reactions.getNormal());
        }
        return false;
    }

    public static boolean disableRoof() {
        Logging.debug("Setting Roof Settings");
        Options.setRemoveRoofsEnabled(true);
        return false;
    }

    public static boolean setChatTransparent() {
        Logging.debug("Setting Chatbox Transparent Settings");
        return Timing.waitCondition(() -> Options.setChatboxTransparent(true), Reactions.getNormal());

    }

    public static boolean setClickThroughChatBox() {
        if (!Options.isChatboxTransparent()) {
            setChatTransparent();
            General.sleep(Reactions.getNormal());
        }
        Logging.debug("Setting Clickthrough Chatbox Settings");
        return Timing.waitCondition(() -> Options.setChatboxClickThrough(true), Reactions.getNormal());
    }


    public static boolean shiftDrop() {
        Logging.debug("Setting Shift Drop Settings");
        return Timing.waitCondition(() -> Options.setShiftClickDropEnabled(true), Reactions.getNormal());
    }


    public static boolean zoomOut() {
        final int ZOOM_MASTER = 116;
        final int ZOOM_CHILD = 99;
        if (GameTab.open(GameTab.TABS.OPTIONS)) {

        }
        return false;
    }

    public static boolean escClose() {
        final int SETTING = 1224;
        final int OPTIONS_MASTER = 134;
        if (Game.getSetting(SETTING) < 0) {
            return true;
        } else {
            if (openOptions()) {
                RSInterface keybinds = Entities.find(InterfaceEntity::new)
                        .inMaster(OPTIONS_MASTER)
                        .actionContains("Keybinds")
                        .getFirstResult();
                if (keybinds != null) {
                    keybinds.click();
                    General.sleep(Reactions.getNormal());
                }
                RSInterface escToggle = Entities.find(InterfaceEntity::new)
                        .inMaster(OPTIONS_MASTER)
                        .textEquals("Esc closes the current interface")
                        .getFirstResult();
                if (escToggle != null) {
                    escToggle.getSibling(General.random(0, 1)).click();
                    General.sleep(Reactions.getNormal());
                }
            }

        }
        Logging.debug("Setting Esc Close Settings");
        return Game.getSetting(SETTING) < 0;
    }
}
