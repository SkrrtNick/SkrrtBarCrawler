package scripts.skrrt_api.util.functions;

import org.tribot.api.Timing;
import org.tribot.api2007.Banking;
import org.tribot.api2007.Game;
import org.tribot.api2007.Inventory;
import org.tribot.api2007.types.RSItem;
import org.tribot.api2007.types.RSItemDefinition;
import scripts.skrrt_api.util.items.BankItem;
import scripts.skrrt_api.util.items.ItemReq;
import scripts.skrrt_api.util.items.Offer;
import scripts.skrrt_api.util.numbers.Prices;
import scripts.skrrt_api.util.numbers.Reactions;

import java.util.ArrayList;
import java.util.Collections;

public class Banking07 extends Banking {

    public static boolean withdrawEvent(ArrayList<BankItem> bankItems, boolean close) {
        Collections.shuffle(bankItems);
        for (BankItem bankItem : bankItems) {
            Logging.debug("Item ("+bankItem.getId()+") required for" ,bankItem.isRequiredFor());
            String name = "";
            int withdrawAmount;
            if(Game.getSetting(bankItem.getGameSetting())>bankItem.getNeededUntil()){
                Logging.debug("We have proceeded into the quest and therefore can remove an item ("+ bankItem.getId() +") from the list of required items");
                continue;
            }
            if(!bankItem.isRequiredFor()){
                Logging.debug("Item ("+bankItem.getId()+") required for" ,bankItem.isRequiredFor());
                continue;
            }
            if(bankItem.requirementsMet()){
                Logging.debug("We have already fulfilled the requirements for one of the tasks, removing ("+ bankItem.getId() +") from the list of required items");
                continue;
            }
            if (Banking.openBank()) {
                Sleep.until(Banking07.isBankLoaded());
                if(!Banking07.getWithdrawQuantity().equals(WITHDRAW_QUANTITY.WITHDRAW_ALL)){
                    Banking07.setWithdrawQuantity(WITHDRAW_QUANTITY.WITHDRAW_ALL);
                    Sleep.until(Banking07.getWithdrawQuantity().equals(WITHDRAW_QUANTITY.WITHDRAW_ALL));
                }
                if(bankItem.getId() > 0){
                    name = RSItemDefinition.get(bankItem.getId()).getName();
                    if (Banking.find(bankItem.getId()).length > 0) {
                        if(Banking07.getStack(bankItem.getId())==bankItem.getCount()){
                            bankItem.setCount(0);
                        }
                        Banking.withdraw(bankItem.getCount(), bankItem.getId());
                        Sleep.until(Inventory07.getCount(bankItem.getId())>0);
                        if (Inventory.getCount(bankItem.getId()) < bankItem.getCount()) {
                            if (name != null && bankItem.isTradeable()) {
                                Logging.debug("Withdraw Event Failure, we don't have enough of " + name + ", we need " + bankItem.getCount() + " but only have " + Inventory.getCount(bankItem.getId()));
                                return false;
                            }
                        } else if (Inventory.getCount(bankItem.getId()) >= bankItem.getCount()) {
                            Logging.debug("Withdraw Event Success, we withdrew " + Inventory.getCount(bankItem.getId()) + "x " + name);
                        }
                    } else if(bankItem.isTradeable()) {
                        Logging.debug("Withdraw Event Failure, we don't have enough of " + name + ", we need " + bankItem.getCount() + " but only have " + Inventory.getCount(bankItem.getId()));
                        return false;
                    }
                } else if  (bankItem.getIds().length > 0){
                    name = RSItemDefinition.get(Banking.find(bankItem.getIds())[0].getID()).getName();
                    if (Banking.find(bankItem.getIds()).length > 0) {
                        if(Banking07.getStack(bankItem.getIds())==bankItem.getCount()){
                            bankItem.setCount(0);
                        }
                        Banking.withdraw(bankItem.getCount(), bankItem.getIds());
                        Timing.waitCondition(() -> Inventory.getCount(bankItem.getIds()) > 0, 10000);
                        if (Inventory.getCount(bankItem.getIds()) < bankItem.getCount()) {
                            if (name != null && bankItem.isTradeable()) {
                                Logging.debug("Withdraw Event Failure, we don't have enough of " + name + ", we need " + bankItem.getCount() + " but only have " + Inventory.getCount(bankItem.getIds()));
                                return false;
                            }
                        } else if (Inventory.getCount(bankItem.getIds()) >= bankItem.getCount()) {
                            Logging.debug("Withdraw Event Success, we withdrew " + Inventory.getCount(bankItem.getIds())+ "x " + name);
                        }
                    } else if(bankItem.isTradeable()) {
                        Logging.debug("Withdraw Event Failure, we don't have enough of " + name + ", we need " + bankItem.getCount() + " but only have " + Inventory.getCount(bankItem.getIds()));
                        return false;
                    }
                }

            }
        }
        if(close){
            Banking07.close();
        }
        return true;
    }


    public static boolean withdrawItem(int ID, int count) {
        if (Banking.openBank()) {
            if (Banking.find(ID).length > 0) {
                Banking.withdraw(count, ID);
                Timing.waitCondition(() -> Inventory.getCount(ID) > 0, 10000);
                Banking07.close();
                return Inventory.find(ID).length > 0;
            }
        }
        return false;
    }

    public static boolean withdrawCoins(boolean close) {
        final int COINS = 995;
        if (Banking.openBank()) {
            if (Banking.find(995).length > 0) {
                Banking.withdraw(0, COINS);
                Timing.waitCondition(() -> Inventory.getCount(COINS) > 0, 10000);
            }
            if (close) {
                Banking07.close();
            }
        }
        return Inventory.getCount(COINS) > 0;
    }

    public static boolean withdrawItems(boolean close, int count, int... IDs) {
        for (int i : IDs) {
            if (Banking.openBank()) {
                Timing.waitCondition(Banking07::isBankLoaded, Reactions.getNormal());
                if (Banking.find(i).length > 0) {
                    Banking.withdraw(count, i);
                    Timing.waitCondition(() -> Inventory.getCount(i) > 0, 10000);
                }
            }
        }
        if (close) {
            Banking.close();
        }
        return Inventory.getCount(IDs) > 0;
    }

    public static boolean checkItemReqs(ArrayList<ItemReq> itemReqs, ArrayList<Offer> offers) {
        for (ItemReq i : itemReqs) {
            String item = "";
            int ID = 0;
            int price = 0;
            if (i.isTeleport()) {
                item = RSItemDefinition.get(i.getTradeableID(i.getItemID())).getName();
                ID = i.getItemID()[i.getItemID().length - 1];
            } else {
                item = RSItemDefinition.get(i.getItemID()[0]).getName();
                ID = i.getItemID()[0];
            }
            price = (int) Math.round(Prices.getPrices(ID).get() * 1.5);
            if (!i.isTask() || Banking07.getStack(ID) >= i.getQuantity() || i.getRequiredCheck() >= i.getRequiredUntil()) {
                continue;
            }
            Timing.waitCondition(Banking07::isBankLoaded, Reactions.getNormal());

            if (Banking07.isBankLoaded() && !i.isTeleport() && Banking07.getStack(ID) < i.getQuantity()) {
                Logging.message("Exchange", "Item Name: " + item + " Item ID: " + ID + " Price: " + price);
                Logging.debug(item + " Stack: " + Banking07.getStack(ID));
                offers.add(new Offer(item, price, i.getQuantity() - Banking07.getStack(ID), false));
            } else {
                if (i.isTeleport()) {
                    if (Banking07.getStack(i.getItemID()) >= i.getQuantity()) {
                        continue;
                    }
                    item = RSItemDefinition.get(i.getTradeableID(i.getItemID())).getName();
                    ID = i.getItemID()[i.getItemID().length - 1];
                    price = (int) Math.round(Prices.getPrices(ID).get() * 1.5);
                    Logging.message("Exchange", "Item Name: " + item + " Item ID: " + ID + " Price: " + price);
                } else {
                    item = RSItemDefinition.get(i.getItemID()[0]).getName();
                    ID = i.getItemID()[0];
                    price = (int) Math.round(Prices.getPrices(ID).get() * 1.5);
                    Logging.message("Exchange", "Item Name: " + item + " Item ID: " + ID + " Price: " + price);
                }
                offers.add(new Offer(item, price, i.getQuantity(), false));
            }
        }
        return true;
    }

    public static int getStack(int... ID) {
        RSItem[] item = Banking.find(ID);
        if (item.length > 0) {
            return item[0].getStack();
        } else {
            return 0;
        }
    }

}
