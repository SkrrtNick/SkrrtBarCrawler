package scripts.skrrt_api.util.functions;

import scripts.skrrt_api.util.items.BankItem;

import java.util.ArrayList;

public class Inventory07 extends org.tribot.api2007.Inventory {

    public static int getFreeSlots() {
        return 28 - Inventory07.getAll().length;
    }

    public static boolean isEmpty() {
        return Inventory07.getAll().length == 0;
    }
    public static boolean hasRequired(ArrayList<BankItem> bankItems){
        for(BankItem bankItem : bankItems){
            if(!bankItem.requirementsMet()){
                if(Inventory07.getCount(bankItem.getId())==0){
                    return false;
                }
            }
        } return true;
    }



}
