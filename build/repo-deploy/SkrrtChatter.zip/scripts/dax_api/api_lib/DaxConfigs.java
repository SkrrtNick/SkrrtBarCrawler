package dax.api_lib;

public class DaxConfigs {

    public static boolean logging = true;

}
