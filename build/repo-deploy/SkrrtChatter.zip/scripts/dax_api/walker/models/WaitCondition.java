package dax.walker.models;

public interface WaitCondition {
    boolean action();
}
