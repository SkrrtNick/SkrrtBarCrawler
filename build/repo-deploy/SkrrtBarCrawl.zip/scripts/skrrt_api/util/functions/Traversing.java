package scripts.skrrt_api.util.functions;


import org.tribot.api.General;
import org.tribot.api.Timing;
import org.tribot.api.interfaces.Positionable;
import org.tribot.api2007.Game;
import org.tribot.api2007.Player;
import org.tribot.api2007.Walking;
import org.tribot.api2007.WebWalking;
import org.tribot.api2007.types.RSArea;
import org.tribot.api2007.types.RSNPC;
import org.tribot.api2007.types.RSObject;
import org.tribot.api2007.types.RSTile;
import org.tribot.api2007.util.DPathNavigator;
import dax.api_lib.DaxWalker;
import dax.api_lib.WebWalkerServerApi;
import dax.api_lib.models.DaxCredentials;
import dax.api_lib.models.DaxCredentialsProvider;
import dax.shared.helpers.BankHelper;
import dax.walker_engine.WalkingCondition;
import scripts.entityselector.Entities;
import scripts.entityselector.finders.prefabs.NpcEntity;
import scripts.entityselector.finders.prefabs.ObjectEntity;
import scripts.skrrt_api.util.antiban.Antiban;
import scripts.skrrt_api.util.items.ItemCollections;
import scripts.skrrt_api.util.numbers.Reactions;


public class Traversing {
    private static final int[] GRAND_EXCHANGE_TELEPORTS = {11988, 11986, 11984, 11982, 11980, 8007, 1706, 1708, 1710, 1712, 11976, 11978};
    private static final RSArea GRAND_EXCHANGE = new RSArea(new RSTile(3160, 3494, 0), new RSTile(3169, 3485, 0));
    private static int attempt = 0;

    public static void walkToBank() {
        if (!BankHelper.isInBank()) {
            Antiban.activateRun();
            DaxWalker.walkToBank();
            Sleep.until(Banking07::isInBank);
        }
    }

    public static boolean walkToGE() {
        Antiban.activateRun();
        if (GRAND_EXCHANGE.contains(Player07.getPosition())) {
            return true;
        }
        if (Player07.distanceTo(GRAND_EXCHANGE.getRandomTile()) < 70 && !GRAND_EXCHANGE.contains(Player07.getPosition())) {
            Traversing.walkTo(GRAND_EXCHANGE.getRandomTile());
        }

        if (Inventory07.getCount(GRAND_EXCHANGE_TELEPORTS) == 0) {
            RSTile GE = GRAND_EXCHANGE.getRandomTile();
            if (Banking07.isInBank() && Player07.distanceTo(GE) > 70) {
                if (Banking07.openBank()) {
                    Timing.waitCondition(Banking07::isBankLoaded, Reactions.getNormal());
                    Banking07.withdraw(1, GRAND_EXCHANGE_TELEPORTS);
                    Timing.waitCondition(() -> Inventory07.getCount(GRAND_EXCHANGE_TELEPORTS) > 0, Reactions.getNormal());
                    if (Banking07.close()) {
                        Logging.debug("Distance to GE", Player07.distanceTo(GE));
                        Traversing.walkTo(GE);
                    }
                }
            } else if (!Banking07.isInBank()) {
                Traversing.walkToBank();
            }
        } else {
            Traversing.walkTo(GRAND_EXCHANGE.getRandomTile());
        }

        return GRAND_EXCHANGE.contains(Player07.getPosition());
    }

    public static boolean smartWalk(Positionable pos) {
        if (Player07.distanceTo(pos) > General.random(3, 10)) {
            Antiban.activateRun();
            int decide = Reactions.getDecision(2);
            DPathNavigator path = new DPathNavigator();
            Positionable[] screenPath = path.findPath(pos);
            if (decide <= 100 && Player.getPosition().distanceTo(pos) < 30) {
                return Walking.walkScreenPath(screenPath);
            } else {
                return WebWalking.walkTo(pos);
            }
        } else {
            return true;
        }
    }


    public static boolean shortestWalk(Positionable pos) {
        DPathNavigator path = new DPathNavigator();
        if (path.traverse(pos)) {
            return true;
        }
        return WebWalking.walkTo(pos);
    }

    public static boolean walkToObject(int[] ID) {
        RSObject obj = Entities.find(ObjectEntity::new)
                .idEquals(ID)
                .sortByDistance()
                .getFirstResult();
        if (obj != null && Player.getPosition().distanceTo(obj) > 10) {
            return Walking.blindWalkTo(obj);
        }
        return false;
    }

    public static boolean walkToObject(String name) {
        RSObject obj = Entities.find(ObjectEntity::new)
                .nameEquals(name)
                .getFirstResult();
        if (obj != null && Player.getPosition().distanceTo(obj) > 10) {
            return Walking.blindWalkTo(obj);
        }
        return false;
    }

    public static boolean walkToNpc(String name) {
        RSNPC npc = Entities.find(NpcEntity::new)
                .nameEquals(name)
                .getFirstResult();
        if (npc != null) {
            return Walking.blindWalkTo(npc);
        }
        return false;
    }


    public static boolean walkTo(RSArea area) {
        RSTile tile = area.getRandomTile();
        if (!area.contains(Player.getPosition())) {
            if (DaxWalker.walkTo(tile, () -> {
                Antiban.activateRun();
                if (area.contains(Player07.getPosition())) {
                    return WalkingCondition.State.EXIT_OUT_WALKER_SUCCESS;
                }
                return WalkingCondition.State.CONTINUE_WALKER;
            })) {
                Logging.message("Walker", "Navigating to " + area.getRandomTile());
                Sleep.until(()->area.contains(Player07.getPosition()));
                attempt = 0;
            } else {
                attempt++;
                Logging.debug("Walker failed to produce a path, attempt: " + attempt);
                if (attempt == 3) {
                    Logging.debug("Walker failed to produce a path 3 times, using DPathNavigator");
                    DPathNavigator path = new DPathNavigator();
                    path.traverse(tile);
                    Sleep.until(()->area.contains(Player07.getPosition()));
                }
            }
            Sleep.until(()->area.contains(Player07.getPosition()));
        }
        return area.contains(Player.getPosition());
    }


    public static boolean walkTo(Positionable positionable) {
        if (Player07.distanceTo(positionable) < 8) {
            return true;
        }
        Antiban.activateRun();
        int x = General.random(0, 3);
        int y = General.random(0, 3);
        RSTile newPos = positionable.getPosition().translate(x, y);
        if (!Player07.getPosition().equals(newPos)) {
            if (DaxWalker.walkTo(newPos)) {
                Logging.message("Walker", "Navigating to " + newPos);
                Sleep.until(()->Player07.getPosition().equals(newPos));
                attempt = 0;
            } else {
                attempt++;
                Logging.debug("Walker failed to produce a path, attempt: " + attempt);
                General.sleep(60);
                if (attempt >= 3) {
                    Logging.debug("Walker failed to produce a path 3 times, using DPathNavigator");
                    DPathNavigator path = new DPathNavigator();
                    path.traverse(positionable);
                }

            }
            Sleep.until(()->Player07.getPosition().equals(newPos));
        } else {
            return true;
        }
        return Player07.getPosition().equals(newPos);
    }

    public static boolean walkTo(Positionable positionable, int attempt) {
        int count = 0;
        Antiban.activateRun();
        int distance = General.random(0, 6);
        if (Player07.distanceTo(positionable) > distance) {
            if (DaxWalker.walkTo(positionable) && (Player07.getPosition().distanceTo(positionable) > 50 || attempt > 0)) {
                Logging.message("Walker", "Navigating to " + positionable);
                Sleep.until(()->Player07.distanceTo(positionable) <= distance);
                count = 0;
            } else if (attempt == 0 && Player07.getPosition().distanceTo(positionable) < 50) {
                Logging.message("DPath", "Navigating to " + positionable);
                DPathNavigator path = new DPathNavigator();
                path.traverse(positionable);
                Sleep.until(()->Player07.distanceTo(positionable) <= distance);
            } else {
                count++;
                Logging.debug("Walker failed to produce a path, attempt: " + attempt);
                General.sleep(60);
                if (attempt >= count) {
                    Logging.debug("Walker failed to produce a path 3 times, using DPathNavigator");
                    DPathNavigator path = new DPathNavigator();
                    path.setAcceptAdjacent(true);
                    path.traverse(positionable);
                    Sleep.until(()->Player07.distanceTo(positionable) <= distance);
                }

            }
            Timing.waitCondition(() -> Player07.distanceTo(positionable) <= distance, 6000);
        }
        return Player07.distanceTo(positionable) <= distance;
    }

    public static void setDaxKey(boolean publicKey) {
        WebWalkerServerApi.getInstance().setDaxCredentialsProvider(new DaxCredentialsProvider() {
            @Override
            public DaxCredentials getDaxCredentials() {
                if (publicKey) {
                    return new DaxCredentials("sub_DPjXXzL5DeSiPf", "PUBLIC-KEY");
                } else {
                    return new DaxCredentials("sub_JmRkbIB2XRYqmf", "7227dd88-8182-4cd9-a3d9-00b8fa6ff56e");
                }
            }
        });
    }

    public static boolean drinkStamina() {
        if (Inventory07.getCount(ItemCollections.getStaminaPotions()) == 0) {
            return false;
        } else {
            if (Game.getRunEnergy() < General.random(1, 20)) {
                int run = Game.getRunEnergy();
                Interaction.selectItem(ItemCollections.getStaminaPotions(), "Drink");
                Sleep.until(()->Game.getRunEnergy() > run);
                return true;
            }
        }
        return false;
    }

    public static WalkingCondition stamina = () -> {
        drinkStamina();
        Antiban.activateRun();
        return WalkingCondition.State.CONTINUE_WALKER;
    };

}
