package scripts.skrrt_api.util.numbers;

import org.tribot.api.General;
import org.tribot.api.interfaces.Positionable;
import org.tribot.api2007.types.RSArea;

import java.util.Random;

public class Randomisation {

    public static Positionable getPosition(Positionable... pos) {
        if (pos.length == 0) {
            return null;
        }
        return pos[General.random(0, pos.length - 1)];
    }

    public static int getRandomWithExclusion(Random rnd, int start, int end, Integer... exclude) {
        int random = start + rnd.nextInt(end - start + 1 - exclude.length);
        for (int ex : exclude) {
            if (random < ex) {
                break;
            }
            random++;
        }
        return random;
    }

    public static RSArea getArea(RSArea... areas) {
        if (areas.length == 0) {
            return null;
        }
        return areas[General.random(0, areas.length - 1)];
    }
}