package dax.walker.models.enums;

public enum MoveActionResult {
    SUCCESS,
    FAILED,
    FATAL_ERROR
}
