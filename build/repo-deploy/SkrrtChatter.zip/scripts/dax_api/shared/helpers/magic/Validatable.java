package dax.shared.helpers.magic;


public interface Validatable {
    boolean canUse();
}
