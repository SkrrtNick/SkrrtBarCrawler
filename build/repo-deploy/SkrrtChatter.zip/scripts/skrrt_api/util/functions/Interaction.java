package scripts.skrrt_api.util.functions;


import dax.walker_engine.interaction_handling.NPCInteraction;
import obf.Re;
import org.tribot.api.Clicking;
import org.tribot.api.DynamicClicking;
import org.tribot.api.General;
import org.tribot.api.Timing;
import org.tribot.api.input.Keyboard;
import org.tribot.api.interfaces.Positionable;
import org.tribot.api2007.*;
import org.tribot.api2007.ext.Filters;
import org.tribot.api2007.types.*;
import scripts.entityselector.Entities;
import scripts.entityselector.finders.prefabs.*;
import scripts.skrrt_api.util.antiban.Antiban;
import scripts.skrrt_api.util.numbers.Reactions;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;


public class Interaction {

    public static boolean walkOrClose(Positionable pos) {
        int decide = Reactions.getDecision(2);
        if (decide <= 100) {
            Interfaces.closeAll();
            Traversing.shortestWalk(pos);
            return true;
        } else if (decide > 100) {
            return Traversing.shortestWalk(pos);
        }
        return false;
    }

    public static boolean clickClosest(String name) {
        if (Player07.getPosition().distanceTo(Traversing.getClosest(name)) < 15) {
            return false;
        }
        return Clicking.click(name);
    }


    public static boolean typing(String word) {
        List<Character> typing = new ArrayList<Character>();
        if (word.contains(" ")) {
            String[] split = word.split(" ");
            char[] chars = split[General.random(0, split.length - 1)].toCharArray();
            if (chars.length - 1 > 3) {
                for (char c : chars) {
                    typing.add(c);
                    General.sleep(Reactions.getPredictable());
                }
                int size = typing.size();
                int omit = General.random(0, size - 3);
                for (int i = 0; i < size - omit; i++) {
                    Keyboard.typeKeys(typing.get(i));
                }
                General.sleep(Reactions.getPredictable());
                return true;
            } else {
                for (char c : chars) {
                    Keyboard.typeKeys(c);
                }
                General.sleep(Reactions.getPredictable());
                return true;
            }
        } else {
            char[] chars = word.toCharArray();
            if (chars.length - 1 > 3) {
                for (char c : chars) {
                    typing.add(c);
                }
                int size = typing.size();
                int omit = General.random(0, size - 3);
                for (int i = 0; i < omit; i++) {
                    Keyboard.typeKeys(typing.get(i));
                }
                General.sleep(Reactions.getPredictable());
                return true;
            } else {
                for (char c : chars) {
                    Keyboard.typeKeys(c);
                }
                General.sleep(Reactions.getPredictable());
                return true;
            }
        }
    }

    public static boolean pickupItem(int id) {
        int count = Inventory07.getCount(id);
        RSGroundItem item = Entities.find(GroundItemEntity::new)
                .idEquals(id)
                .getFirstResult();
        if (item != null) {
            if (!item.isClickable()) {
                item.adjustCameraTo();
            }
            item.click();
            return Sleep.until(count < Inventory07.getCount(id));
        }
        return false;
    }


    public static void handleQuestNPC(String name, String currentTask, RSArea area, String... dialogue) {
        if (area.contains(Player07.getPosition()) && !NPCInteraction.isConversationWindowUp()) {
            clickNPC(name);
            Timing.waitCondition(() -> NPCInteraction.isConversationWindowUp(), Reactions.getNormal());
            NPCInteraction.handleConversation(dialogue);
        } else if (!area.contains(Player07.getPosition())) {
            Antiban.activateRun();
            Traversing.walkTo(area.getRandomTile(), 0);
        }
    }

    public static boolean handleQuestNPC(String name, RSArea area, String... dialogue) {
        if (area.contains(Player07.getPosition()) && !NPCInteraction.isConversationWindowUp()) {
            clickNPC(name);
            Timing.waitCondition(() -> NPCInteraction.isConversationWindowUp(), Reactions.getNormal());
            NPCInteraction.handleConversation(dialogue);
        } else if (!area.contains(Player07.getPosition())) {
            Antiban.activateRun();
            Traversing.walkTo(area.getRandomTile());
            return false;
        } return !NPCInteraction.isConversationWindowUp();
    }

    public static boolean handleQuestNPC(String name, String... dialogue) {
        if (!NPCInteraction.isConversationWindowUp()) {
            NPCInteraction.clickNpcAndWaitChat(Filters.NPCs.nameEquals(name),"Talk-to");
            NPCInteraction.handleConversation(dialogue);
        } return !NPCInteraction.isConversationWindowUp();
    }

    public static boolean handleQuestNPC(String name, Positionable positionable, int attempts, String... dialogue) {
        if (Player07.distanceTo(positionable) < General.random(0, 5) && !NPCInteraction.isConversationWindowUp()) {
            clickNPC(name);
            Sleep.until(NPCInteraction.isConversationWindowUp());
            NPCInteraction.handleConversation(dialogue);
            Sleep.until(!NPCInteraction.isConversationWindowUp());
        } else if (Player07.distanceTo(positionable) > General.random(0, 5)) {
            Antiban.activateRun();
            Traversing.walkTo(positionable, attempts);
            return false;
        } return !NPCInteraction.isConversationWindowUp();
    }

    public static boolean handleQuestNPC(String name, Positionable positionable, String... dialogue) {
        int distance = General.random(0, 5);
        if (Player07.distanceTo(positionable) < distance && !NPCInteraction.isConversationWindowUp()) {
            clickNPC(name);
            Sleep.until(NPCInteraction.isConversationWindowUp());
            NPCInteraction.handleConversation(dialogue);
            General.sleep(Reactions.getNormal());
        } else if (Player07.distanceTo(positionable) > distance) {
            Antiban.activateRun();
            Traversing.walkTo(positionable);
            return false;
        } return !NPCInteraction.isConversationWindowUp();
    }

    public static boolean clickOrActionNPC(String name, String action) {
        RSNPC[] npc = NPCs.findNearest(name);
        if (npc.length == 0) {
            return false;
        } else if (!npc[0].isClickable()) {
            npc[0].adjustCameraTo();
        }
        int decide = Reactions.getDecision(2);
        if (decide <= 100) {
            return npc[0].click();
        } else if (decide > 100 && !NPCInteraction.isConversationWindowUp()) {
            return npc[0].click(action);
        }
        return false;
    }

    public static boolean clickUseOrActionNPC(String name, String action, int ID) {
        RSNPC[] npc = NPCs.findNearest(name);
        if (npc.length == 0) {
            return false;
        } else if (!npc[0].isClickable()) {
            npc[0].adjustCameraTo();
        }
        int decide = Reactions.getDecision(3);
        if (decide <= 100) {
            return npc[0].click();
        } else if (decide > 100 && decide < 200 && !NPCInteraction.isConversationWindowUp()) {
            return npc[0].click(action);
        } else if (decide >= 200) {
            RSItem item = Entities.find(ItemEntity::new)
                    .idEquals(ID)
                    .getFirstResult();
            if (item != null) {
                if (Inventory07.open()) {
                    item.click();
                    Timing.waitCondition(() -> Game.getItemSelectionState() == 1, Reactions.getNormal());
                    npc[0].click();
                }
            }
        }
        return false;
    }

    public static boolean clickNPC(String name) {
        RSNPC[] npc = NPCs.findNearest(name);
        if (npc.length == 0) {
            return false;
        } else if (!npc[0].isClickable()) {
            npc[0].adjustCameraTo();
        }
        return npc[0].click();
    }

    public static boolean clickNPC(RSNPC npc) {
        if (!npc.isClickable()) {
            npc.adjustCameraTo();
        }
        return npc.click();
    }



    public static RSObject getObject(int[] ID) {
        RSObject obj = Entities.find(ObjectEntity::new)
                .idEquals(ID)
                .sortByDistance()
                .getFirstResult();
        if (obj != null) {
            return obj;
        }
        return null;
    }



    public static RSObject getObject(int ID) {
        RSObject obj = Entities.find(ObjectEntity::new)
                .idEquals(ID)
                .sortByDistance()
                .getFirstResult();
        if (obj != null) {
            return obj;
        }
        return null;
    }

    public static RSObject getObject(String name) {
        RSObject obj = Entities.find(ObjectEntity::new)
                .nameEquals(name)
                .sortByDistance()
                .getFirstResult();
        if (obj != null) {
            return obj;
        }
        return null;
    }

    public static RSObject getObject(String name, String action) {
        RSObject obj = Entities.find(ObjectEntity::new)
                .nameEquals(name)
                .actionsEquals(action)
                .sortByDistance()
                .getFirstResult();
        if (obj != null) {
            return obj;
        }
        return null;
    }

    public static boolean clickNPC(String name, String action) {
        RSNPC[] npc = NPCs.findNearest(name);
        if (npc.length == 0 || !npc[0].isClickable()) {
            return false;
        } else if (!npc[0].isClickable()) {
            npc[0].adjustCameraTo();
        }
        return npc[0].click(action);
    }

    public static boolean clickObject(RSObject object) {
        if (object == null) {
            return false;
        } else if (!object.isClickable()) {
            object.adjustCameraTo();
        }
        return DynamicClicking.clickRSObject(object, object.getDefinition().getActions()[0]);
    }


    public static boolean clickObject(String name) {
        RSObject[] object = Objects.findNearest(10, name);
        if (object.length == 0) {
            return false;
        } else if (!object[0].isClickable()) {
            object[0].adjustCameraTo();
        }
        return object[0].click();
    }

    public static boolean clickObject(String name, String action) {
        RSObject[] object = Objects.findNearest(10, name);
        if (object.length == 0) {
            return false;
        } else if (!object[0].isClickable()) {
            object[0].adjustCameraTo();
        }
        return object[0].click(action);
    }


    public static boolean dynamicClickObject(String name, String action) {
        RSObject[] object = Objects.findNearest(10, name);
        if (object.length == 0) {
            return false;
        } else if (!object[0].isClickable()) {
            object[0].adjustCameraTo();
        }
        return DynamicClicking.clickRSObject(object[0], action);
    }


    public static boolean mineRock(int ore, int[] rock) {
        int currentOre = Inventory.getCount(ore);
        RSTile rPos = null;
        int rID;
        RSObject r = getObject(rock);
        if (r != null) {
            rID = r.getID();
            rPos = r.getPosition();
            int wait = (int) Reactions.getNormal();
            Traversing.walkTo(rPos, General.randomSD(1, 4, 1));
            General.println("Rock Pos: " + rPos);
            General.println("Player Pos: " + Player07.getPosition());
            General.sleep(wait);
            Antiban.generateTrackers(wait);
            if (Interaction.clickObject(rock)) {
                Antiban.timedActions();
                Timing.waitCondition(() -> rID != r.getID(), Reactions.getAFK());
            }
        }
        return currentOre < Inventory.getCount(ore);
    }


    public static boolean objectExists(String name) {
        RSObject obj = Entities.find(ObjectEntity::new)
                .nameEquals(name)
                .getFirstResult();
        return obj != null;
    }

    public static boolean objectExists(int[] ID) {
        RSObject obj = Entities.find(ObjectEntity::new)
                .idEquals(ID)
                .sortByDistance()
                .getFirstResult();
        return obj != null;
    }

    public static boolean clickObject(int[] ID) {
        RSObject obj = Entities.find(ObjectEntity::new)
                .idEquals(ID)
                .sortByDistance()
                .getFirstResult();
        if (obj != null) {
            if (!obj.isClickable()) {
                obj.adjustCameraTo();
            }
            return obj.click();
        }
        return false;
    }

    public static boolean clickObject(int ID) {
        RSObject obj = Entities.find(ObjectEntity::new)
                .idEquals(ID)
                .sortByDistance()
                .getFirstResult();
        if (obj != null) {
            if (!obj.isClickable()||!obj.isOnScreen()) {
                obj.adjustCameraTo();
            }
            return obj.click();
        }
        return false;
    }


    public static boolean npcExists(String name) {
        RSNPC npc = Entities.find(NpcEntity::new)
                .nameEquals(name)
                .getFirstResult();
        return npc != null;
    }

    public static RSNPC getNPC(String name) {
        RSNPC npc = Entities.find(NpcEntity::new)
                .nameEquals(name)
                .getFirstResult();
        return npc;
    }

    public static RSNPC getNPC(String name, String action) {
        RSNPC npc = Entities.find(NpcEntity::new)
                .nameEquals(name)
                .actionsEquals(action)
                .getFirstResult();
        return npc;
    }

    public static boolean equipItems(int count, String action, int... ids) {
        if (Banking.find(ids).length > 0) {
            Banking.withdraw(count, ids);
        }
        if (Inventory07.find(ids).length > 0) {
            for (int id : ids) {
                RSItem[] i = Inventory07.find(id);
                if (i.length > 0) {
                    i[0].click(action);
                    General.sleep(Reactions.getPredictable());
                }
            }
        }
        return Equipment.isEquipped(ids);
    }

    public static boolean selectItem(int id1, String action) {
        General.sleep(Reactions.getPredictable());
        int decision = Reactions.getDecision(3);
        if (decision < 100) {
            RSItem[] item1 = (Entities.find(ItemEntity::new)
                    .idEquals(id1)
                    .getResults());
            if (item1.length > 0) {
                Logging.debug("Attempting to click " + item1[0].getDefinition().getName());
                item1[General.random(0, item1.length - 1)].click(action);
            }
        } else if (decision <= 200) {
            Optional<RSItem> item1 = Arrays.stream(Entities.find(ItemEntity::new)
                    .idEquals(id1)
                    .getResults()).min(ItemEntity.getClosestComparator());
            if (item1.isPresent()) {
                Logging.debug("Attempting to click " + item1.get().getDefinition().getName());
                item1.get().click(action);
            }
        } else {
            RSItem item1 = Entities.find(ItemEntity::new)
                    .idEquals(id1)
                    .getFirstResult();
            if (item1 != null) {
                Logging.debug("Attempting to " + action + " " + item1.getDefinition().getName());
                item1.click(action);
            }
        }
        return Game.getItemSelectionState() == 1;
    }

    public static boolean selectItem(int id1) {
        General.sleep(Reactions.getPredictable());
        int decision = Reactions.getDecision(3);
        if (decision < 100) {
            RSItem[] item1 = (Entities.find(ItemEntity::new)
                    .idEquals(id1)
                    .getResults());
            if (item1.length > 0) {
                Logging.debug("Attempting to click " + item1[0].getDefinition().getName());
                item1[General.random(0, item1.length - 1)].click("Use");
            }
        } else if (decision <= 200) {
            Optional<RSItem> item1 = Arrays.stream(Entities.find(ItemEntity::new)
                    .idEquals(id1)
                    .getResults()).min(ItemEntity.getClosestComparator());
            if (item1.isPresent()) {
                Logging.debug("Attempting to click " + item1.get().getDefinition().getName());
                item1.get().click("Use");
            }
        } else {
            RSItem item1 = Entities.find(ItemEntity::new)
                    .idEquals(id1)
                    .getFirstResult();
            if (item1 != null) {
                Logging.debug("Attempting to click " + item1.getDefinition().getName());
                item1.click("Use");
            }
        }
        return Game.getItemSelectionState() == 1;
    }


    public static void combineItems(int id1, int id2) {
        General.sleep(Reactions.getPredictable());
        int decision = Reactions.getDecision(3);
        if (decision < 100) {
            RSItem[] item1 = (Entities.find(ItemEntity::new)
                    .idEquals(id1)
                    .getResults());
            if (item1.length > 0) {
                Logging.debug("Attempting to click " + item1[0].getDefinition().getName());
                if (item1[General.random(0, item1.length - 1)].click("Use")) {
                    Optional<RSItem> item2 = Arrays.stream(Entities.find(ItemEntity::new)
                            .idEquals(id2).getResults()).min(ItemEntity.getClosestComparator());
                    if (item2.isPresent()) {
                        General.sleep(Reactions.getPredictable());
                        Logging.debug("Attempting to click " + item2.get().getDefinition().getName());
                        item2.get().click();
                    }
                }
            }
        } else if (decision <= 200) {
            Optional<RSItem> item1 = Arrays.stream(Entities.find(ItemEntity::new)
                    .idEquals(id1)
                    .getResults()).min(ItemEntity.getClosestComparator());
            if (item1.isPresent()) {
                Logging.debug("Attempting to click " + item1.get().getDefinition().getName());
                if (item1.get().click("Use")) {
                    Optional<RSItem> item2 = Arrays.stream(Entities.find(ItemEntity::new)
                            .idEquals(id2)
                            .getResults()).min(ItemEntity.getClosestComparator());
                    if (item2.isPresent()) {
                        General.sleep(Reactions.getPredictable());
                        Logging.debug("Attempting to click " + item2.get().getDefinition().getName());
                        item2.get().click();
                    }
                }
            }
        } else if (decision < 250) {
            Optional<RSItem> item1 = Arrays.stream(Entities.find(ItemEntity::new)
                    .idEquals(id2)
                    .getResults()).min(ItemEntity.getClosestComparator());
            if (item1.isPresent()) {
                Logging.debug("Attempting to click " + item1.get().getDefinition().getName());
                if (item1.get().click("Use")) {
                    Optional<RSItem> item2 = Arrays.stream(Entities.find(ItemEntity::new)
                            .idEquals(id1)
                            .getResults()).min(ItemEntity.getClosestComparator());
                    if (item2.isPresent()) {
                        General.sleep(Reactions.getPredictable());
                        Logging.debug("Attempting to click " + item2.get().getDefinition().getName());
                        item2.get().click();
                    }
                }
            }
        } else {
            RSItem[] item1 = (Entities.find(ItemEntity::new)
                    .idEquals(id1)
                    .getResults());
            if (item1.length > 0) {
                Logging.debug("Attempting to click " + item1[0].getDefinition().getName());
                if (item1[0].click("Use")) {
                    Optional<RSItem> item2 = Arrays.stream(Entities.find(ItemEntity::new)
                            .idEquals(id2)
                            .getResults()).min(ItemEntity.getClosestComparator());
                    if (item2.isPresent()) {
                        General.sleep(Reactions.getPredictable());
                        Logging.debug("Attempting to click " + item2.get().getDefinition().getName());
                        item2.get().click();
                    }
                }
            }
        }
    }

    public static void makeAll(int master, String name) {
        RSInterface make = Entities.find(InterfaceEntity::new)
                .inMaster(master)
                .isNotHidden()
                .componentNameContains(name)
                .getFirstResult();
        RSInterface action = Entities.find(InterfaceEntity::new)
                .inMasterAndChild(master, 13)
                .isNotHidden()
                .getFirstResult();
        if (make != null && action != null) {
            String actionText = action.getChild(make.getIndex() - 14).getText();
            int decision = Reactions.getDecision(1);
            Logging.debug("Found the interface, action is " + actionText);
            if (decision <= 50) {
                General.sleep(Reactions.getNormal());
                make.click();
            } else {
                if (actionText.equals("Space")) {
                    Keyboard.typeString(" ");
                } else {
                    Keyboard.typeString(actionText);
                }
            }

        }
    }

    public static void handleContinue() {
        if (Interfaces.isInterfaceSubstantiated(NPCChat.getClickContinueInterface()) || Interfaces.isInterfaceSubstantiated(11) || Interfaces.isInterfaceSubstantiated(229)) {
            int decision = Reactions.getDecision(3);
            General.sleep(Reactions.getNormal());
            if (decision <= 100) {
                //does nothing intentionally
            }
            if (decision > 100 && decision <= 200) {
                Keyboard.typeString(" ");
                Logging.message("Pressing space to clear Click to Continue interface");
            }

            if (decision > 200 && decision <= 300) {
                if (Interfaces.isInterfaceSubstantiated(11)) {
                    Interfaces.get(11).getChild(4).click();
                } else if (Interfaces.isInterfaceSubstantiated(229)){
                    Interfaces.get(229).getChild(2).click();
                }
                else {
                    NPCChat.clickContinue(true);
                }
                Logging.message("Clicking to clear Click to Continue interface");
            }
        }
    }

    public static void combineItems(String name1, String name2) {
        General.sleep(Reactions.getPredictable());
        int decision = Reactions.getDecision(3);
        if (decision < 100) {
            RSItem[] item1 = (Entities.find(ItemEntity::new)
                    .nameEquals(name1)
                    .getResults());
            if (item1.length > 0) {
                Logging.debug("Attempting to click " + item1[0].getDefinition().getName());
                if (item1[General.random(0, item1.length - 1)].click("Use")) {
                    Optional<RSItem> item2 = Arrays.stream(Entities.find(ItemEntity::new)
                            .nameEquals(name2)
                            .getResults()).min(ItemEntity.getClosestComparator());
                    if (item2.isPresent()) {
                        General.sleep(Reactions.getPredictable());
                        Logging.debug("Attempting to click " + item2.get().getDefinition().getName());
                        item2.get().click();
                    }
                }
            }
        } else if (decision <= 200) {
            Optional<RSItem> item1 = Arrays.stream(Entities.find(ItemEntity::new)
                    .nameEquals(name1)
                    .getResults()).min(ItemEntity.getClosestComparator());
            if (item1.isPresent()) {
                Logging.debug("Attempting to click " + item1.get().getDefinition().getName());
                if (item1.get().click("Use")) {
                    Optional<RSItem> item2 = Arrays.stream(Entities.find(ItemEntity::new)
                            .nameEquals(name2)
                            .getResults()).min(ItemEntity.getClosestComparator());
                    if (item2.isPresent()) {
                        General.sleep(Reactions.getPredictable());
                        Logging.debug("Attempting to click " + item2.get().getDefinition().getName());
                        item2.get().click();
                    }
                }
            }
        } else if (decision < 250) {
            Optional<RSItem> item1 = Arrays.stream(Entities.find(ItemEntity::new)
                    .nameEquals(name2)
                    .getResults()).min(ItemEntity.getClosestComparator());
            if (item1.isPresent()) {
                Logging.debug("Attempting to click " + item1.get().getDefinition().getName());
                if (item1.get().click("Use")) {
                    Optional<RSItem> item2 = Arrays.stream(Entities.find(ItemEntity::new)
                            .nameEquals(name1)
                            .getResults()).min(ItemEntity.getClosestComparator());
                    if (item2.isPresent()) {
                        General.sleep(Reactions.getPredictable());
                        Logging.debug("Attempting to click " + item2.get().getDefinition().getName());
                        item2.get().click();
                    }
                }
            }
        } else {
            RSItem[] item1 = (Entities.find(ItemEntity::new)
                    .nameEquals(name1)
                    .getResults());
            if (item1.length > 0) {
                Logging.debug("Attempting to click " + item1[0].getDefinition().getName());
                if (item1[0].click("Use")) {
                    Optional<RSItem> item2 = Arrays.stream(Entities.find(ItemEntity::new)
                            .nameEquals(name2)
                            .getResults()).min(ItemEntity.getClosestComparator());
                    if (item2.isPresent()) {
                        General.sleep(Reactions.getPredictable());
                        Logging.debug("Attempting to click " + item2.get().getDefinition().getName());
                        item2.get().click();
                    }
                }
            }
        }
    }
}

