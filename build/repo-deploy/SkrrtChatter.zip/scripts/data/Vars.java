package scripts.data;

import java.util.ArrayList;

public class Vars {

    public static double playerSeed = 0;
    public static boolean isRunning;
    public static String status = "Logging in";
    public static String npcName = "";
    public static String action = "";
    public static int x = 0;
    public static int y = 0;
    public static int z = 0;
    public static ArrayList<String> dialogue = new ArrayList<>();

}
