package scripts;

import dax.api_lib.WebWalkerServerApi;
import dax.api_lib.models.DaxCredentials;
import dax.api_lib.models.DaxCredentialsProvider;
import org.tribot.api.General;
import org.tribot.api.Timing;
import org.tribot.api.input.Mouse;
import org.tribot.api2007.Login;
import org.tribot.script.Script;
import org.tribot.script.ScriptManifest;
import org.tribot.script.interfaces.Arguments;
import org.tribot.script.interfaces.Painting;
import org.tribot.script.interfaces.Starting;
import scripts.data.Vars;

import scripts.skrrt_api.task.Task;
import scripts.skrrt_api.task.TaskSet;
import scripts.skrrt_api.util.numbers.Reactions;
import scripts.skrrt_api.util.numbers.SeedGenerator;
import scripts.tasks.Chatter;

import java.awt.*;
import java.util.Arrays;
import java.util.HashMap;


public class SkrrtChatter extends Script implements Starting, PaintInfo, Painting, Arguments {


    @ScriptManifest(name = "SkrrtChatter", authors = {"SkrrtNick"}, category = "Tools")

    private final FluffeesPaint SkrrtPaint = new FluffeesPaint(this, FluffeesPaint.PaintLocations.BOTTOM_LEFT_PLAY_SCREEN, new Color[]{new Color(255, 251, 255)}, "Trebuchet MS", new Color[]{new Color(93, 156, 236, 127)},
            new Color[]{new Color(39, 95, 175)}, 1, false, 5, 3, 0);


    @Override
    public void run() {
        General.println("[SkrrtChatter] Welcome to SkrrtChatter");
        General.println("[SkrrtChatter] Interacting with " + Vars.npcName + " via " + Vars.action);
        if(!Vars.dialogue.isEmpty()){
            General.println("[SkrrtChatter] Dialogue: " + Vars.dialogue.toString());
            General.println("[SkrrtChatter] Dialogue size: " + (Vars.dialogue.size()) );
        }
        General.println("[SkrrtChatter] Navigating to: " + "x: " + Vars.x + " y: " + Vars.y + " z: " + Vars.z);
        Timing.waitCondition(()-> Login.getLoginState().equals(Login.STATE.LOGINSCREEN), Reactions.getAFK());
        SeedGenerator seed = new SeedGenerator();
        while (seed.getPlayerSeed() == 0) {
            seed.generateRandom();
            Vars.playerSeed = seed.getPlayerSeed();
            if ((int) Vars.playerSeed * 100 > 200) {
                Mouse.setSpeed(General.random(130, 200));
            } else {
                Mouse.setSpeed((int) (Vars.playerSeed * 100));
            }
        }

        //settings:Aubury:Teleport:3255:3400:0
        //



        TaskSet tasks = new TaskSet(new Chatter());

        while (Vars.isRunning) {
            Task task = tasks.getValidTask();
            if (task != null) {
                Vars.status = task.toString();
                task.execute();
            }
            General.sleep(600);
        }

    }

    @Override
    public void onStart() {
        WebWalkerServerApi.getInstance().setDaxCredentialsProvider(new DaxCredentialsProvider() {
            @Override
            public DaxCredentials getDaxCredentials() {
                return new DaxCredentials("sub_DPjXXzL5DeSiPf", "PUBLIC-KEY");
            }
        });

    }

    @Override
    public String[] getPaintInfo() {
        return new String[]{"SkrrtChatter V0.7b", "Time ran: " + SkrrtPaint.getRuntimeString(), "Status: " + Vars.status};
    }


    @Override
    public void onPaint(Graphics graphics) {
        SkrrtPaint.paint(graphics);
    }

    @Override
    public void passArguments(HashMap<String, String> hashMap) {
        String scriptSelect = hashMap.get("custom_input");
        String clientStarter = hashMap.get("autostart");
        String input = clientStarter != null ? clientStarter : scriptSelect;
        String[] settings = input.split("(?<!%),");
        if (settings.length > 0) {
            for (String s : settings) {
                if (s.contains("settings:" )&& s.contains(";")) {
                    Vars.npcName = s.split(":")[1] != null ? s.split(":")[1] : null;
                    Vars.action = s.split(":")[2] != null ? s.split(":")[2] : null;
                    Vars.x = s.split(":")[3] != null ? Integer.parseInt(s.split(":")[3]) : null;
                    Vars.y = s.split(":")[4] != null ? Integer.parseInt(s.split(":")[4]) : null;
                    Vars.z = s.split(":")[5] != null ? Integer.parseInt(s.split(":")[5]) : null;
                    Vars.dialogue.addAll(Arrays.asList(s.split(":")[6].replaceAll("%","").split(";")));
                } else if (s.contains("settings:")){
                    Vars.npcName = s.split(":")[1] != null ? s.split(":")[1] : null;
                    Vars.action = s.split(":")[2] != null ? s.split(":")[2] : null;
                    Vars.x = s.split(":")[3] != null ? Integer.parseInt(s.split(":")[3]) : null;
                    Vars.y = s.split(":")[4] != null ? Integer.parseInt(s.split(":")[4]) : null;
                    Vars.z = s.split(":")[5] != null ? Integer.parseInt(s.split(":")[5]) : null;
                }
            } Vars.isRunning = true;
        }
    }
}