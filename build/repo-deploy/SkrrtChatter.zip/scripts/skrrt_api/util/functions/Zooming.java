package scripts.skrrt_api.util.functions;

import org.tribot.api.General;
import org.tribot.api.Timing;
import org.tribot.api.input.Mouse;
import org.tribot.api2007.Interfaces;
import org.tribot.api2007.Options;
import org.tribot.api2007.types.RSInterface;
import org.tribot.api2007.types.RSVarBit;

public class Zooming {

    /**
     * Adjust camera to set zoomLevel
     *
     * @param zoomLevel - 0 is zoomed out, 100 is zoomed in
     * @return True if successfully changed camera zoom to set level
     */
    public static boolean setCameraZoom(int zoomLevel) {
        RSInterface button = Interfaces.get(116, 46);
        RSInterface zoom = Interfaces.get(116, 60);
        RSInterface screen = Interfaces.get(122);
        RSVarBit varbit = RSVarBit.get(6357);
        if (varbit.getValue() == 1 && Options.TABS.CONTROLS.open() && button != null)
            if (!button.click() || !Timing.waitCondition(() -> varbit.getValue() == 0, General.random(1000, 2000)))
                return false;
        if (zoom != null && screen != null) {
            int startZoom = (int) zoom.getAbsoluteBounds().getX();
            boolean b = startZoom < 600 + zoomLevel ? true : false;
            screen.hover();
            long t = System.currentTimeMillis();
            while (!(zoom.getAbsoluteBounds().getX() < zoomLevel + 605
                    && zoom.getAbsoluteBounds().getX() > zoomLevel + 595) && Timing.timeFromMark(t) < 5000) {
                Mouse.scroll(b);
                General.sleep(50);
            }
            return true;
        }
        return false;
    }

}
