package scripts.tasks;

import dax.walker_engine.interaction_handling.NPCInteraction;
import org.tribot.api.General;
import org.tribot.api.Timing;
import org.tribot.api2007.Game;
import org.tribot.api2007.Login;
import org.tribot.api2007.types.RSNPC;
import org.tribot.api2007.types.RSTile;
import scripts.data.Vars;
import scripts.skrrt_api.task.Priority;
import scripts.skrrt_api.task.Task;
import scripts.skrrt_api.util.functions.Interaction;
import scripts.skrrt_api.util.functions.Player07;
import scripts.skrrt_api.util.functions.Traversing;
import scripts.skrrt_api.util.numbers.Reactions;

public class Chatter implements Task {

    @Override
    public String toString() {
        return Vars.status;
    }

    @Override
    public Priority priority() {
        return Priority.HIGH;
    }

    @Override
    public boolean validate() {
        return Login.getLoginState().equals(Login.STATE.INGAME);
    }

    @Override
    public void execute() {

        RSNPC npc = Interaction.getNPC(Vars.npcName);
        RSTile customLocation = new RSTile(Vars.x, Vars.y, Vars.z);
        if (Game.getGameState() == 30 && (npc == null || !Interaction.npcExists(Vars.npcName) || !npc.isClickable())) {
            Vars.status = "Traversing to " + Vars.npcName;
            Traversing.walkTo(customLocation);
            if (Player07.distanceTo(customLocation) < 5 && !Interaction.npcExists(Vars.npcName)) {
                General.println("[Debug] Unable to find NPC, stopping script");
                Vars.isRunning = false;
            }
        }
        if (Interaction.npcExists(Vars.npcName)) {
            Interaction.clickNPC(Vars.npcName, Vars.action);
            General.sleep(Reactions.getNormal());
        }
        if (!Vars.dialogue.isEmpty() && Player07.distanceTo(customLocation) < 5) {
            while (!NPCInteraction.isConversationWindowUp()) {
                Interaction.clickNPC(Vars.npcName, Vars.action);
                Timing.waitCondition(NPCInteraction::isConversationWindowUp, 2000);
            }
            Vars.status = "Handling dialogue";
            NPCInteraction.handleConversation(Vars.dialogue.toArray(new String[Vars.dialogue.size()]));
        }
        General.sleep(Reactions.getAFK());
        General.println("[SkrrtChatter] Completed the task, thanks for using Skrrt Chatter");
        Vars.isRunning = false;
    }

}
