package scripts.skrrt_api.listeners.inventory;
// taken from Fluffee's api

public interface InventoryListener {
    void inventoryItemGained(int id, int count);
    void inventoryItemLost(int id, int count);
}
