package scripts.skrrt_api.util.functions;

import org.tribot.api.Timing;
import org.tribot.api2007.Banking;
import org.tribot.api2007.Interfaces;
import org.tribot.api2007.Inventory;
import org.tribot.api2007.types.RSInterface;
import org.tribot.api2007.types.RSItem;
import scripts.skrrt_api.util.numbers.Reactions;

import java.util.ArrayList;

public class Banking07 extends Banking {

    public static boolean closeBankTutorial() {
        if (Banking07.isBankLoaded() && Interfaces.isInterfaceSubstantiated(664, 29)) {
            Logging.debug("Closing Bank Tutorial");
            RSInterface close = Interfaces.get(664, 29);
            if (close != null) {
                close.click();
                Sleep.until(()->!Interfaces.isInterfaceSubstantiated(664));
            }
        }
        return !Interfaces.isInterfaceSubstantiated(664, 29);
    }

    public static RSItem[] find(ArrayList<Integer> ids){
        for(Integer id:ids){
            if(Banking.find(id).length > 0){
                return Banking.find(id);
            }
        } return new RSItem[0];
    }


    public static boolean withdrawCoins(boolean close) {
        final int COINS = 995;
        if (Banking.openBank()) {
            if (Banking.find(995).length > 0) {
                Banking.withdraw(0, COINS);
                Timing.waitCondition(() -> Inventory.getCount(COINS) > 0, 10000);
            }
            if (close) {
                Banking07.close();
            }

        }
        return Inventory.getCount(COINS) > 0;
    }

    public static boolean withdrawItems(boolean close, int count, int... IDs) {
        for (int i : IDs) {
            if (Banking.openBank()) {
                Timing.waitCondition(Banking07::isBankLoaded, Reactions.getNormal());
                if (Banking.find(i).length > 0) {
                    Banking.withdraw(count, i);
                    Timing.waitCondition(() -> Inventory.getCount(i) > 0, 10000);
                }
            }
        }
        if (close) {
            Banking.close();
        }
        return Inventory.getCount(IDs) > 0;
    }

    public static int getStack(int... ID) {
        RSItem[] item = Banking.find(ID);
        if (item.length > 0) {
            return item[0].getStack();
        } else {
            return 0;
        }
    }

}
