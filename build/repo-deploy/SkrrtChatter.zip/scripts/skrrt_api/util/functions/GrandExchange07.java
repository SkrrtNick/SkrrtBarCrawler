package scripts.skrrt_api.util.functions;

import org.tribot.api.Clicking;
import org.tribot.api.General;
import org.tribot.api.Timing;
import org.tribot.api2007.*;
import org.tribot.api2007.types.*;

import scripts.entityselector.Entities;
import scripts.entityselector.finders.prefabs.InterfaceEntity;
import scripts.entityselector.finders.prefabs.NpcEntity;
import scripts.skrrt_api.util.numbers.Reactions;

public class GrandExchange07 extends GrandExchange {




    public static boolean collectItems() {
        GrandExchange.collectItems(COLLECT_METHOD.ITEMS, GrandExchange.getCollectItems());
        return !getCollectAll();
    }

    public static boolean getItem(String name) {
        RSGEOffer[] offers = GrandExchange.getOffers();
        for (RSGEOffer o : offers) {
            if(o.getItemName() == null){
                continue;
            }
            if (o.getItemName().equals(name)) {
                return true;
            }
        }
        return false;
    }

    public static boolean getItem(int ID) {
        RSGEOffer[] offers = GrandExchange.getOffers();
        for (RSGEOffer o : offers) {
            if (o.getItemID() == ID) {
                return true;
            }
        }
        return false;
    }

    public static boolean changeQuantity(int quantity) {
        Timing.waitCondition(() -> GrandExchange.getQuantity() != -1, 6000);
        if (quantity != GrandExchange.getQuantity()) {
            return GrandExchange.setQuantity(quantity);
        }
        return false;
    }

    public static boolean incrementPrice(int number) {
        Timing.waitCondition(() -> Entities.find(InterfaceEntity::new).inMasterAndChild(465, 24).actionNotContains("5%").getFirstResult() != null, 6000);
        if (number > 0) {
            RSInterface increase = Entities.find(InterfaceEntity::new).inMasterAndChild(465, 24).actionContains("+5%").getFirstResult();
            if (increase != null) {
                for (int i = 0; i < number; i++) {
                    increase.click();
                }
                return true;
            }
        } else if(number < 0) {
            RSInterface decrease = Entities.find(InterfaceEntity::new).inMasterAndChild(465, 24).actionContains("-5%").getFirstResult();
            int n = Math.abs(number);
            if (decrease != null) {
                for (int i = 0; i < n; i++) {
                    decrease.click();
                }
                return true;
            }
        }
        return false;
    }


    public static boolean hasFreeSlots() {
        RSInterface freeSlot = Entities.find(InterfaceEntity::new)
                .inMaster(465)
                .actionContains("Buy")
                .isNotHidden()
                .getFirstResult();
        if (freeSlot != null) {
            return true;
        }
        return false;
    }

    public static boolean open() {
        if (Interfaces.isInterfaceSubstantiated(465)) {
            return true;
        }
        RSNPC clerk = Entities.find(NpcEntity::new)
                .nameEquals("Grand Exchange Clerk")
                .sortByDistance()
                .getFirstResult();
        if (clerk != null) {
            if(!clerk.isClickable()){
                clerk.adjustCameraTo();
            }
            Clicking.click("Exchange Grand Exchange Clerk", clerk);
        }
        Timing.waitCondition(()->Interfaces.isInterfaceSubstantiated(465), Reactions.getNormal());
        return Interfaces.isInterfaceSubstantiated(465);
    }

    public static boolean close() {
        RSInterface close = Entities.find(InterfaceEntity::new)
                .inMaster(465)
                .actionContains("Close")
                .getFirstResult();
        if (close != null && !close.isHidden()) {
            return close.click();
        }
        return false;
    }


    public static boolean abort(int ID) {
        RSGEOffer[] offers = GrandExchange.getOffers();
        for (RSGEOffer o : offers) {
            if (o.getItemID() == ID) {
                return o.click("Abort offer");
            }
        }
        return false;
    }

    public static boolean abort() {
        RSInterface abort = Entities.find(InterfaceEntity::new)
                .inMasterAndChild(465, 6)
                .actionContains("Abort")
                .getFirstResult();
        if (abort != null && !abort.isHidden()) {
            abort.click("Abort");
        }
        GrandExchange07.collectAll("Collect to bank");
        return GrandExchange07.hasFreeSlots();
    }

    public static boolean getCollectAll() {
        RSInterface collect = Entities.find(InterfaceEntity::new)
                .inMasterAndChild(465, 6)
                .actionContains("Collect")
                .getFirstResult();
        if (collect != null && !collect.isHidden()) {
            return true;
        }
        return false;
    }

    public static boolean collectAll() {
        RSInterface collect = Entities.find(InterfaceEntity::new)
                .inMasterAndChild(465, 6)
                .actionContains("Collect")
                .getFirstResult();
        if (collect != null && !collect.isHidden()) {
            General.sleep(Reactions.getNormal());
            return collect.click();
        }
        return false;
    }

    public static boolean collectAll(String action) {
        RSInterface collect = Entities.find(InterfaceEntity::new)
                .inMasterAndChild(465, 6)
                .actionContains("Collect")
                .getFirstResult();
        if (collect != null && !collect.isHidden()) {
            return collect.click(action);
        }
        return false;
    }


}
