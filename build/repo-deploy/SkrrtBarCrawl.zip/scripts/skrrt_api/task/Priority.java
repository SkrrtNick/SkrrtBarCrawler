package scripts.skrrt_api.task;

public enum Priority {

    HIGH,
    MEDIUM,
    LOW,
    NONE

}