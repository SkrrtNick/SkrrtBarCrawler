package scripts.skrrt_api.util.items;

import lombok.Getter;
import lombok.Setter;
@Getter @Setter
public class ItemReq {
    private int[] itemID;
    private int quantity;
    private int requiredUntil;
    private int requiredCheck;
    private boolean task;
    private boolean teleport;

    public ItemReq(int quantity, boolean task, int requiredCheck, int requiredUntil, boolean teleport, int ... itemID) {
        this.itemID = itemID;
        this.quantity = quantity;
        this.task = task;
        this.requiredCheck = requiredCheck;
        this.requiredUntil = requiredUntil;
        this.teleport = teleport;
    }



    /**
     *
     * @param returns the last value in an array, on the assumption that it is the tradeable ID
     * @return int
     */

    public int getTradeableID(int[] ids){
        return ids[ids.length - 1];
    }

}
